package classdesign;

import uipackage.GlobalVariable;
import uipackage.UI;

public class MainTest {

	public static void main(String[] args) {
		
		GameManager gManager=new GameManager();
		UI ui=new UI(gManager);
		ui.go();
		GlobalVariable.init();
	}

}
