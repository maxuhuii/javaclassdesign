package classdesign;

public enum ToolType {

	ADD_TANK,

	BOMB,

	SPADE,

	TIMER,
	
	STAR,
	
	GUN,
	
	DOUBLEATTACK
}
