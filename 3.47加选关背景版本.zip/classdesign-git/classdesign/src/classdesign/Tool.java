package classdesign;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.Random;

import uipackage.GamePanel;
import utils.ImageUtils;


public class Tool extends ImageDetails{
	
	private static String[] imgURL= {
			ImageUtils.ADD_TANK,
			ImageUtils.BOMB,
			ImageUtils.SPADE,
			ImageUtils.TIMER,
			ImageUtils.STAR,
			ImageUtils.GUN,
			ImageUtils.DOUBLEATTACK
	};
	
	private static Image [] toolImgs= {
			Toolkit.getDefaultToolkit().createImage(imgURL[0]),
			Toolkit.getDefaultToolkit().createImage(imgURL[1]),
			Toolkit.getDefaultToolkit().createImage(imgURL[2]),
			Toolkit.getDefaultToolkit().createImage(imgURL[3]),
			Toolkit.getDefaultToolkit().createImage(imgURL[4]),
			Toolkit.getDefaultToolkit().createImage(imgURL[5]),
			Toolkit.getDefaultToolkit().createImage(imgURL[6])
	};
	
	private int timer=0;//��ʱ��
	private int aliveTime=4500;//���ߴ���ʱ��
	private  Random r=new Random();//���������
	private static  int height=20,width=20;
	ToolType type;//��������
	private boolean alive=true;//���״̬
	
	/**
	 * ��ȡ����ʵ��
	 * @param x ���ߵ�һ�γ��ֵĺ�����
	 * @param y ���ߵ�һ�γ��ֵ�������
	 * @return һ�����߶���
	 */
	public static Tool getToolInstance(int x,int y) {
		return new Tool(x,y);
	}
	public Tool(int x,int y) {
		super(x,y,width,height);
		type=ToolType.values()[r.nextInt(7)];
	}
	
	public void changeToolType() {
		type=ToolType.values()[r.nextInt(7)];
		x=r.nextInt(550);
		y=r.nextInt(500);
		this.alive=true;
	}
	
	/**
	 * ��������
	 * @param g ����
	 */
	public void draw(Graphics g) {
		if(timer>aliveTime) {
			timer=0;
			setAlive(false);
			//changeToolType();
		}else {
			g.drawImage(toolImgs[type.ordinal()], x, y, null);
			//System.out.println("�Ƿ񻭳ɹ���"+b+",type="+type+",x="+x+",y="+y);
			timer+=GamePanel.FRESHTIME;
		}
	}
	/**
	 * ���ô��״̬
	 * @param alive ���״̬
	 */
	public void setAlive(boolean alive) {
		this.alive=alive;
		timer=0;
	}
	/**
	 * ���ߵĴ��״̬
	 * @return
	 */
	public boolean getAlive() {
		return this.alive;
	}
}
