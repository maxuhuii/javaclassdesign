package uipackage;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JFrame;

import classdesign.GameManager;






public class UI {
	public JFrame frame;
	public GameManager gameManager;
	
	public UI(GameManager gManager)
	{
		//���ν���Ϸ����������
		this.gameManager=gManager;
	}
	public void go()
	{
		frame=new MainFrame();
		GlobalVariable.mainFrame=frame;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GlobalVariable.drawPanel=new StartPanel();
		frame.getContentPane().add(BorderLayout.CENTER,GlobalVariable.drawPanel);
		frame.setVisible(true);
	}
}
