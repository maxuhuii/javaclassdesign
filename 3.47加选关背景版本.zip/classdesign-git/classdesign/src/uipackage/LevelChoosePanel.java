package uipackage;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextListener;

import javax.swing.ImageIcon;
import javax.swing.JTextField;

public class LevelChoosePanel extends MyDrawPanel
{
	Frame frame;
	JTextField textField=new JTextField();
	Textlistener listTextlistener;
	
	public LevelChoosePanel()
	{
		this.frame=GlobalVariable.mainFrame;
		listTextlistener=new Textlistener();
		textField.setText("������ؿ�");
		textField.addActionListener(listTextlistener);
		this.add(textField);
		
	}
	class Textlistener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO �Զ����ɵķ������
			String tempString=textField.getText();
			GlobalVariable.level=Integer.valueOf(tempString);
			System.out.println(""+GlobalVariable.level);
			frame.requestFocus();
			GlobalVariable.changeScene(new StartPanel());
		}
		
	}
	public void paintComponent(Graphics g)
	{
		//���ﴴ������ѡ�������嵥����
		Image image=new ImageIcon("chooseLevelbg.jpg").getImage();
		g.drawImage(image,0,0,this);
		//g.setColor(Color.orange);
		//g.fillRect(20, 50, 100, 100);
	}
}
