package uipackage;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class MyDrawPanel extends JPanel{
	public void paintComponent(Graphics g)
	{
		//������Ϸ��ʼ����
		//Image image=new ImageIcon("bg.jpg").getImage();
		//g.drawImage(image,0,0,this);
		//g.setColor(Color.orange);
		//g.fillRect(20, 50, 100, 100);
	}
}
