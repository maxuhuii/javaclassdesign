package map;

import utils.ImageUtils;

public class landmineWall extends Wall
{
	public landmineWall(int x,int y)
	{
		super(x,y,ImageUtils.LANDMINEWALL);
	}
}
